/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright 2009-2012 JKU Linz
                                Copyright 2012-     DCS Computing GmbH, Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    This code is designed to realize coupled CFD-DEM simulations using LIGGGHTS
    and OpenFOAM(R). Note: this code is not part of OpenFOAM(R) (see DISCLAIMER).
\*---------------------------------------------------------------------------*/

#include "error.H"
#include "Random.H"

#include "HaiderLevenspielDrag.H"
#include "addToRunTimeSelectionTable.H"
#include "dataExchangeModel.H"
#include <boost/random/linear_congruential.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/uniform_01.hpp>
#include <boost/random/variate_generator.hpp>
#include <ctime>
#include "mpi.h"

typedef struct {
                    double val;
                    int rank;
            } temp;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(HaiderLevenspielDrag, 0);

addToRunTimeSelectionTable
(
    forceModel,
    HaiderLevenspielDrag,
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
HaiderLevenspielDrag::HaiderLevenspielDrag
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    forceModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),
    velFieldName_(propsDict_.lookup("velFieldName")),
    U_(sm.mesh().lookupObject<volVectorField> (velFieldName_)),
    voidfractionFieldName_(propsDict_.lookup("voidfractionFieldName")),
    voidfraction_(sm.mesh().lookupObject<volScalarField> (voidfractionFieldName_)),
    kFieldName_(propsDict_.lookup("kFieldName")),
    kit_(sm.mesh().lookupObject<volScalarField> (kFieldName_)),
    tfFieldName_(propsDict_.lookup("tfFieldName")),
    tf_(sm.mesh().lookupObject<volScalarField> (tfFieldName_)),
    sigmaFieldName_(propsDict_.lookup("sigmaFieldName")),
    sigma_(sm.mesh().lookupObject<volScalarField> (sigmaFieldName_)),
    UsFieldName_(propsDict_.lookup("granVelFieldName")),
    UsField_(sm.mesh().lookupObject<volVectorField> (UsFieldName_)),
    sphr_(1.),
    equalDia_(1.),
    scaleDia_(1.),
    scaleDrag_(1.),
    RWM_(0.),
    s_(1.),
    rcut_(0.3),
    usek_(0.0),
    utaum_(0.0),
    usex_(0.0),
    useadv_(0.0),
    beta_(1.0),
    lem_(GREAT),
    zeimcut_(-GREAT),
    zcut_(0.0),
    slicing_(0.0),
    nSlice_(10.0),
    interpolateU_(0.0)
{

    //Append the field names to be probed
    particleCloud_.probeM().initialize(typeName, "HaiderLevenspielDrag.logDat");
    particleCloud_.probeM().vectorFields_.append("dragForce"); //first entry must the be the force
    particleCloud_.probeM().vectorFields_.append("Urel");        //other are debug
    particleCloud_.probeM().scalarFields_.append("Rep");          //other are debug
    particleCloud_.probeM().scalarFields_.append("Cd");                 //other are debug
    particleCloud_.probeM().scalarFields_.append("voidfraction");       //other are debug
    particleCloud_.probeM().writeHeader();

    particleCloud_.checkCG(true);
    if (propsDict_.found("equalDia"))
      {
          equalDia_=scalar(readScalar(propsDict_.lookup("equalDia")));
          sphr_=scalar(readScalar(propsDict_.lookup("sphr"))); 
      }
    if (propsDict_.found("scaleDia"))
        scaleDia_=scalar(readScalar(propsDict_.lookup("scaleDia")));
    if (propsDict_.found("scaleDrag"))
        scaleDrag_=scalar(readScalar(propsDict_.lookup("scaleDrag")));
    if (propsDict_.found("s"))
        s_=scalar(readScalar(propsDict_.lookup("s")));
    if (propsDict_.found("RWM"))
        RWM_=scalar(readScalar(propsDict_.lookup("RWM")));
    if (propsDict_.found("rcut"))
        rcut_=scalar(readScalar(propsDict_.lookup("rcut")));
    if (propsDict_.found("usek"))
        usek_=scalar(readScalar(propsDict_.lookup("usek")));
    if (propsDict_.found("utaum"))
        utaum_=scalar(readScalar(propsDict_.lookup("utaum")));
    if (propsDict_.found("usex"))
        usex_=scalar(readScalar(propsDict_.lookup("usex")));
    if (propsDict_.found("useadv"))
        useadv_=scalar(readScalar(propsDict_.lookup("useadv")));
    if (propsDict_.found("beta"))
        beta_=scalar(readScalar(propsDict_.lookup("beta")));
    if (propsDict_.found("lem"))
        lem_=scalar(readScalar(propsDict_.lookup("lem")));
    if (propsDict_.found("zeimcut"))
        zeimcut_=scalar(readScalar(propsDict_.lookup("zeimcut")));
    if (propsDict_.found("zcut"))
        zcut_=scalar(readScalar(propsDict_.lookup("zcut")));
    if (propsDict_.found("slicing"))
        slicing_=scalar(readScalar(propsDict_.lookup("slicing")));
    if (propsDict_.found("interpolateU"))
        interpolateU_=scalar(readScalar(propsDict_.lookup("interpolateU")));
    if (propsDict_.found("nSlice"))
        nSlice_=scalar(readScalar(propsDict_.lookup("nSlice")));


    // init force sub model
    setForceSubModels(propsDict_);

    // define switches which can be read from dict
    forceSubM(0).setSwitchesList(0,true); // activate treatExplicit switch
    forceSubM(0).setSwitchesList(2,true); // activate implDEM switch
    forceSubM(0).setSwitchesList(3,true); // activate search for verbose switch
    forceSubM(0).setSwitchesList(4,true); // activate search for interpolate switch
    forceSubM(0).setSwitchesList(8,true); // activate scalarViscosity switch

    // read those switches defined above, if provided in dict
    forceSubM(0).readSwitches();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

HaiderLevenspielDrag::~HaiderLevenspielDrag()
{
}

// * * * * * * * * * * * * * * * public Member Functions  * * * * * * * * * * * * * //

void HaiderLevenspielDrag::setForce
(
) const
{

    if (sphr_ < 1)
        Info << "HaiderLevenspielDrag using spherity = " << sphr_ << endl;
    if (scaleDia_ > 1)
       { Info << "HaiderLevenspielDrag using scale = " << scaleDia_ << endl;
         Info << "equivalent diameter = " << equalDia_ << endl;
       }
    else if (particleCloud_.cg() > 1){
        scaleDia_=particleCloud_.cg();
        Info << "HaiderLevenspielDrag using scale from liggghts cg = " << scaleDia_ << endl;
    }

    const volScalarField& nufField = forceSubM(0).nuField();
    const volScalarField& rhoField = forceSubM(0).rhoField();
    vector position(0,0,0);
    vector positionz(0,0,0);
    vector positionzup(0,0,0);
    vector positionzlo(0,0,0);
    scalar voidfraction(1);
    scalar kit(0.);
    vector Ufluid(0,0,0);
    vector drag(0,0,0);
    vector dragExplicit(0,0,0);
    scalar dragCoefficient(0);
    vector Us(0,0,0);
    vector Ur(0,0,0);
    scalar ds(0);
    scalar nuf(1e-6);
    scalar rho(1000);
    scalar magUr(0);
    scalar Rep(0);
    scalar Cd(0);
    scalar sigma(0);

    // calculate coeffcient A, B, C, D
    scalar AA = exp(2.3288-6.4581*sphr_+2.4486*sphr_*sphr_);    
    scalar BB = 0.0964 + 0.5565*sphr_;
    scalar CC = exp(4.905-13.8944*sphr_+18.4222*sphr_*sphr_-10.2599*sphr_*sphr_*sphr_);
    scalar DD = exp(1.4681+12.2584*sphr_-20.7322*sphr_*sphr_+15.8855*sphr_*sphr_*sphr_);

    // added for Random Walk Model
    scalar tf(0.);
    scalar ux(0.);
    scalar uy(0.);
    scalar uz(0.);
    vector ufl(0.,0.,0.);
    // other time scale
    scalar te(0.);
    scalar tc(0.);
    scalar le(0.);
    scalar tp(0.); 
    scalar etaa(1.);

    scalar up(1e-10);
    scalar vp(1e-10);
    scalar wp(1e-10);
    scalar Xi(2.0);

    //slicing parameters
    scalar rs (0.0);
    scalar zHigh (0.0);
    scalar zLow (0.0);
    scalar xx (0.0);
    scalar yy (0.0);
    scalar dz (0.0);
    scalar zUp (0.0);
    scalar zDown (0.0);
    scalar tetaUp (0.0);
    scalar tetaDown (0.0);
    scalar areaUp (0.0);
    scalar areaDown (0.0);
    scalar areaSlice (0.0);
    vector positionSlice (0,0,0);
    scalar areaTotal;
    vector USlice (0,0,0);
    scalar USliceX (0.0);
    scalar AU2Slice (0.0);
    scalar AU2Total (0.0);
    scalar sgnAU2 (0.0);
    scalar UxBar (0.0);
    scalar zCC (0.0);
    
    scalar ateta1 (0.0);
    scalar ateta2 (0.0);

    scalar twoOverThree(0.66666666667);
    scalar sqrttwoOverThree(0.816496581);

    voidfractionInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("voidfractionInterpolationType",word("cellPoint")),voidfraction_).ptr());
    kInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("kInterpolationType",word("cellPoint")),kit_).ptr());
    tfInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("tfInterpolationType",word("cellPoint")),tf_).ptr());
    sigmaInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("sigmaInterpolationType",word("cellPoint")),sigma_).ptr());
    UInterpolator_.reset(interpolation<vector>::New(propsDict_.lookupOrDefault("UInterpolationType",word("cellPointFace")),U_).ptr());

    #include "setupProbeModel.H"
 
    // without static, randome number will give the same value every time called
    static boost::minstd_rand0 randGen(static_cast<unsigned int>(std::time(0)));//(int)TimingInfo::getNow(true));
    static boost::normal_distribution<double> dist(0.0, 1.0);
    static boost::uniform_01<> dist2;
    static boost::variate_generator<boost::minstd_rand0&,boost::normal_distribution<double> > rnd(randGen,dist);
    static boost::variate_generator<boost::minstd_rand0&,boost::uniform_01<> > rnd2(randGen,dist2);

    /// made sure each processor has total number of particles.

    int np = particleCloud_.numberOfParticles();
// version 1:share the whole chunk to all processors 

// version 2: only share when the information is needed, hope to save time of communication        
// i.e. when particles have crossed processors, or EIM needed to update
    for(int index = 0;index <  np; index++)
    {
            position = particleCloud_.position(index);

            label cellI = particleCloud_.mesh().findCell(position, polyMesh::CELL_TETS);

// version3: only need the random walk for sediment suspension, important message for sheet flow
// because most of the particles are not even moving in sheet flow (inside the bed)
            int myrank;
            double gtmark, gti, glambda1, glambda2, glambda3,ltmark,lti,llambda1,llambda2,llambda3;
            MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

            gtmark = tmark()[index][0];
            gti = ti()[index][0]; 
            glambda1 = ufr()[index][0];
            glambda2 = ufr()[index][1];
            glambda3 = ufr()[index][2];

            if(RWM_!=0.0 && position[2]>zeimcut_)
            {
               temp tempin, tempout;

               tempin.val = tmark()[index][0];
               tempin.rank = myrank;
// find the particle processor, and distribute to all processors
		MPI_Allreduce(&tempin, &tempout, 1, MPI_DOUBLE_INT, MPI_MAXLOC, MPI_COMM_WORLD);

		if (myrank==tempout.rank) {
		ltmark = tmark()[index][0];
		lti =  ti()[index][0];
		llambda1 =  ufr()[index][0];
		llambda2 =  ufr()[index][1];
		llambda3 =  ufr()[index][2];
		}
		else{
		ltmark = 0;
		lti =  0;
		llambda1 =  0;
		llambda2 =  0;
		llambda3 =  0;
		}

		MPI_Allreduce(&ltmark,&gtmark, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		MPI_Allreduce(&lti,&gti, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		MPI_Allreduce(&llambda1,&glambda1, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		MPI_Allreduce(&llambda2,&glambda2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		MPI_Allreduce(&llambda3,&glambda3, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
            }

            drag = vector(0,0,0);
            dragExplicit = vector(0,0,0);
            dragCoefficient = 0;
            Ufluid = vector(0,0,0);

// notice, only enters the following if the particles are found on the current processor        
            if (cellI >= 0) // particle Found
            {
                //position = particleCloud_.position(index);
                positionz = vector(position[0],position[1],position[2]);

               // calculating the mean velocity based on slicing scheme
                if (slicing_ == 1.0)
                {
                rs = particleCloud_.radius(index);
                zHigh = position[2] + rs;
                zLow = position[2] -rs;
       
                xx = position[0];
                yy = position[1];

                dz = (zHigh-zLow)/nSlice_;
                
                areaTotal = 0;
                AU2Total = 0;
                
                scalar nz = 0.0;
                //Info << "dz_Heydar = " << dz << endl;
                for (int iz = 0; iz < nSlice_; iz++ )
                {
                     nz = nz+1;
                     zCC = zLow + (nz-0.5)*dz;
                     zUp = zLow + nz*dz;
                     zDown = zLow + (nz-1)*dz;

                     ateta1 = (zUp-position[2])/rs;
                     ateta2 = (zDown-position[2])/rs;

                     if (ateta1 > 1) ateta1 = 1;
                     if (ateta1 < -1) ateta1 = -1;
                     if (ateta2 > 1) ateta2 = 1;
                     if (ateta2 < -1) ateta2 = -1;

                     tetaUp = 2*acos (ateta1);
                     tetaDown = 2*acos (ateta2);

                     areaUp = rs*rs/2*(tetaUp-sin(tetaUp));
                     areaDown = rs*rs/2*(tetaDown-sin(tetaDown));

                     areaSlice = areaDown - areaUp;

                     positionSlice = vector (xx,yy,zCC);
   
                     areaTotal = areaTotal + areaSlice;
                      
                     //Info << "nz = " << nz << endl; 
                     //Info << "areaSlice = " << areaSlice << endl;
                     //Info << "zCC = " << zCC << endl;
                     //Info << "zUp = " << zUp << endl;
                     //Info << "zDown = " << zDown << endl;
                     //Info << "positionSlice = " << positionSlice << endl;
 
                     label cellSlice = particleCloud_.mesh().findCell(positionSlice, polyMesh::CELL_TETS);
 
                     if (cellSlice < 0) cellSlice = cellI;  
                     USlice = U_[cellSlice];
                     USliceX = USlice [0];
                     AU2Slice = USliceX*mag(USliceX)*areaSlice;
                     AU2Total = AU2Total + AU2Slice;
                }
                     if (AU2Total >= 0) sgnAU2 = 1;
                     if (AU2Total < 0 ) sgnAU2 = -1;
                     UxBar =sgnAU2 * sqrt (mag(AU2Total)/areaTotal);
                }
                //if(forceSubM(0).interpolation())
                if (interpolateU_ == 1.0)
                {
                    voidfraction = voidfractionInterpolator_().interpolate(position,cellI);
                    kit = kInterpolator_().interpolate(positionz,cellI);
                    tf = tfInterpolator_().interpolate(positionz,cellI);
                    sigma = sigmaInterpolator_().interpolate(positionz,cellI);
                    Ufluid = UInterpolator_().interpolate(position,cellI);
                }
                else
                {
                    voidfraction = voidfraction_[cellI];
                    kit = kit_[cellI];
                    tf = tf_[cellI];
                    sigma = sigma_[cellI];
                    Ufluid = U_[cellI];
                }
                /// correction of fluid velocity based on slicing scheme

                //Info << "UFluid1 =  " << Ufluid << endl;
                //Info << "UxBar = " << UxBar << endl;     
 
                if (slicing_ == 1.0)
                {
                   Ufluid = vector(UxBar,Ufluid[1],Ufluid[2]); 
                }

                //Info << "UFluid2 =  " << Ufluid << endl;

                if(voidfraction>1.00) voidfraction = 1.0;
                if(voidfraction<0.3) voidfraction = 0.3;

                ds = 2.0*particleCloud_.radius(index);
                nuf = nufField[cellI];
                rho = max(rho,rhoField[cellI]);
                Us = particleCloud_.velocity(index);
                Ur = Ufluid-Us;
                magUr = mag(Ur);
                Rep = 0.0;
                Cd = 0.0;

// fluctuation velocity scale
                if(usek_==0)
                {
                   wp=min(sqrt(mag(sigma)),utaum_);
                   up=wp;
                   vp=sqrt(max(2.0*kit-up*up-wp*wp,0.0));
                }
                else if(usek_==0.5)
                {
                   up=sqrt((kit/1.3 + sqrt( max(sqr(kit)/1.69-2.0*sqr(sigma),0.0) ))/2.0);
                   wp=mag(sigma)/max(up,1e-10);
                   vp=sqrt(max(2.0*kit-up*up-wp*wp,0.0));
                }
                else
                {
                   up=usek_*sqrttwoOverThree*sqrt(kit);
                   vp=usek_*sqrttwoOverThree*sqrt(kit);
                   wp=usek_*sqrttwoOverThree*sqrt(kit);
                }
                // to check parallel problem
//                kit = 4.78*sqr(utaum_)*exp(-2*positionz[2]/0.021);
 //               tf = 0.27*4.78/9.8*sqrt(positionz[2]*0.021)/utaum_*exp(positionz[2]/0.021); 
 //               up = 2.78*utaum_*exp(-positionz[2]/0.021);
 //               vp = 1.27*utaum_*exp(-positionz[2]/0.021);
 //               wp = 1.27*utaum_*exp(-positionz[2]/0.021);
                //etaa = 1.0;
                etaa = -log(max(1.0-rnd2(),1e-5));
                tf = beta_*etaa*tf;
                le = sqrttwoOverThree*sqrt(kit)*tf;
 
                // we should limit the eddy size, and its characteristic eddy time
                // this is especially important for oscillatory flow, as the eddy turn over time
                // outside the wave boundary layer is extremely large
                le = min(le,lem_);
                tf = min(tf,lem_/utaum_);

                if(position[2]>zeimcut_+lem_)
                {
                   up = 0.0;
                   vp = 0.0;
                   wp = 0.0;
                }

                //up = 0.03; vp = 0.03; wp = 0.03;
                if (magUr > 0)
                {
                    // calc particle Re Nr
                    if(scaleDia_!=1)
                    Rep = equalDia_*voidfraction*magUr/nuf;
                    else
                    Rep = ds*voidfraction*magUr/nuf;

                    // calc fluid drag Coeff (A. Haider and O. Lenvenspiel, 1989, Powder technology)
                    Cd = (24.0/Rep)*(1.0+AA*pow(Rep,BB)) + CC/(1.0+DD/Rep);
                    Xi = 3.7 - 0.65 * exp(-sqr(1.5-log10(Rep))/2.0);
                    Cd = Cd*pow(voidfraction,(2.0-Xi));
                    if(scaleDia_!=1)
                      tp = 2.0*twoOverThree*s_*equalDia_/(magUr*Cd);
                    else
                      tp = 2.0*twoOverThree*s_*ds/(magUr*Cd);
                    // calculate the crossing time
                    tc = tf;
                    if(le<(tp*magUr))
                    {
                       tc = -tp*log(1.0 - le/(tp*magUr) );
                    }
                    te = min(tc,tf); 
                    // limit too small te will not be able to stir the deposited particles)
                    te = max(te,0.41*(11.6*nuf/utaum_)/utaum_);

                    //turbulent part in drag
                    // notice that the updated flucts takes effect in the next time step, 
                    // so they should be updated one time step ahead
                    //if(RWM_!=0.0 && (particleCloud_.mesh().time().value()-gtmark)>=gti) 
                    double told = particleCloud_.mesh().time().value() - particleCloud_.mesh().time().deltaTValue();
                    if(RWM_!=0.0 && (told-gtmark)>=gti) 
                    {
                       // update time scale
                       ufr()[index][0] = rnd();
                       ufr()[index][1] = rnd();
                       ufr()[index][2] = rnd();
                       tmark()[index][0] = particleCloud_.mesh().time().value();
                       ti()[index][0] = te;
                        if(index==200)
                        {
                          Pout << "particle tmark= " << tmark()[index][0] << endl;
                          Pout << "ti = " << te << endl;
                        }
                    }
                    if(RWM_!=0.0 && voidfraction>(1.0-rcut_))
                    {
                    	// now we update the velocity fluctuation
                    	if(usek_!=0){
                          uz = wp*glambda3;
                          if(position[2]<(zcut_+ds) && position[2]>=zcut_)
                          {
                             uz = wp*mag(glambda3);
                          }
                          if(position[2]>(particleCloud_.zhi_-ds))
                          {
                             uz = -wp*mag(glambda3);
                          }
                          if(usex_!=0.0)
                          {
                    	     ux = up*glambda1;
                          }
                          else ux = 0.0;
                          uy = vp*glambda2; 
                        }
                        else {
                          uz = wp*glambda3;
                          if(position[2]<(zcut_+ds) && position[2]>=zcut_)
                          {
                             uz = wp*mag(glambda3);
                          }
                          if(position[2]>(particleCloud_.zhi_-ds))
                          {
                             uz = -wp*mag(glambda3);
                          }
                          if(usex_!=0.0)
                          {
                             ux = -sign(sigma)*uz+up*glambda1;
                          }
                          else ux = 0.0;
                          uy = vp*glambda2;
                        }
                    	ufl = vector(ux,uy,uz);
                        Ufluid = Ufluid + RWM_*ufl;
                        Ur = Ufluid - Us;
                        magUr = mag(Ur);
                     // important to update the drag coefficient, as this is related to the nonlinear behavior of drag
                     // calc fluid drag Coeff (A. Haider and O. Lenvenspiel, 1989, Powder technology)
                        if(scaleDia_!=1)  Rep = equalDia_*voidfraction*magUr/nuf;
                        else Rep = ds*voidfraction*magUr/nuf;
                        Cd = (24.0/Rep)*(1.0+AA*pow(Rep,BB)) + CC/(1.0+DD/Rep);
                        Xi = 3.7 - 0.65 * exp(-sqr(1.5-log10(Rep))/2.0);
                        Cd = Cd*pow(voidfraction,(2.0-Xi));
                     }
                        if(index==200)
                        {
                          Pout << "tmark= " << gtmark << endl;
                          Pout << "ti = " << gti << endl;
                          Pout << "wp = "<< wp << endl;
                          Pout << "pos = "<< position[2] << endl;
                          Pout << "ufx = " << ux << endl;
                          Pout << "ufz = " << uz << endl;
                        }
                    // calc particle's drag
                    if(scaleDia_!=1)
                    {
                    dragCoefficient = 0.125*Cd*rho
                                     *M_PI
                                     *equalDia_*equalDia_
                                     /(scaleDia_*scaleDia_)
                                     *magUr
                                     *scaleDrag_;
                    }
                    else
                    {
                    dragCoefficient = 0.125*Cd*rho
                                     *M_PI
                                     *ds*ds
                                     *magUr;
                    }
                    if (modelType_=="B")
                        dragCoefficient /= voidfraction;

                    drag = dragCoefficient*Ur; //total drag force!

                    forceSubM(0).explicitCorr(drag,dragExplicit,dragCoefficient,Ufluid,U_[cellI],Us,UsField_[cellI],forceSubM(0).verbose(),index);
                }  // end of for (MagUr > 0)

                if(forceSubM(0).verbose() && index >-1 && index <102)
                {
                    Pout << "index = " << index << endl;
                    Pout << "Us = " << Us << endl;
                    Pout << "Ur = " << Ur << endl;
                    Pout << "ds/scale = " << ds/scaleDia_ << endl;
                    Pout << "rho = " << rho << endl;
                    Pout << "nuf = " << nuf << endl;
                    Pout << "voidfraction = " << voidfraction << endl;
                    Pout << "Rep = " << Rep << endl;
                    Pout << "Cd = " << Cd << endl;
                    Pout << "drag (total) = " << drag << endl;
                }

                //Set value fields and write the probe
                if(probeIt_)
                {
                    #include "setupProbeModelfields.H"
                    vValues.append(drag);   //first entry must the be the force
                    vValues.append(Ur);
                    sValues.append(Rep);
                    sValues.append(Cd);
                    sValues.append(voidfraction);
                    particleCloud_.probeM().writeProbe(index, sValues, vValues);
                }
            } // end of for (cell >= 0)
            // write particle based data to global array
            // drag part
            forceSubM(0).partToArray(index,drag,dragExplicit,Ufluid,dragCoefficient);
        } // end of for (index) 
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
