/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright 2009-2012 JKU Linz
                                Copyright 2012-     DCS Computing GmbH, Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    This code is designed to realize coupled CFD-DEM simulations using LIGGGHTS
    and OpenFOAM(R). Note: this code is not part of OpenFOAM(R) (see DISCLAIMER).
\*---------------------------------------------------------------------------*/

#include "error.H"
#include "Random.H"

#include "SamDragSlice.H"
#include "addToRunTimeSelectionTable.H"
#include "dataExchangeModel.H"
#include <boost/random/linear_congruential.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/uniform_01.hpp>
#include <boost/random/variate_generator.hpp>
#include <ctime>
#include <limits>
#include <mpi.h>

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(SamDragSlice, 0);

addToRunTimeSelectionTable
(
    forceModel,
    SamDragSlice,
    dictionary
);


// Convenience struct to hold random number generators.

struct SamDragSlice::RNG
{
    /*
    using Gen = boost::minstd_rand0;
    using DistNormal = boost::normal_distribution<double>;
    using DistUniform = boost::uniform_01<>;
    using RNGNormal = boost::variate_generator<Gen&, DistNormal>;
    using RNGUniform = boost::variate_generator<Gen&, DistUniform>;
    */

    typedef boost::minstd_rand0 Gen;
    typedef boost::normal_distribution<double> DistNormal;
    typedef boost::uniform_01<> DistUniform;
    typedef boost::variate_generator<Gen&, DistNormal> RNGNormal;
    typedef boost::variate_generator<Gen&, DistUniform> RNGUniform;

    Gen gen;
    DistNormal dist_normal;
    DistUniform dist_uniform;
    RNGNormal random_normal;            // rnd
    RNGUniform random_uniform;          // rnd2

    RNG()
    :
        gen(static_cast<unsigned int>(std::time(0))),
        dist_normal(0.0, 1.0),
        dist_uniform(),
        random_normal(gen, dist_normal),
        random_uniform(gen, dist_uniform)
    {}
};

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
SamDragSlice::SamDragSlice
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    forceModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),

    velFieldName_(propsDict_.lookup("velFieldName")),
    U_(sm.mesh().lookupObject<volVectorField>(velFieldName_)),

    voidfractionFieldName_(propsDict_.lookup("voidfractionFieldName")),
    voidfraction_(sm.mesh().lookupObject<volScalarField>(voidfractionFieldName_)),

    kFieldName_(propsDict_.lookup("kFieldName")),
    kit_(sm.mesh().lookupObject<volScalarField>(kFieldName_)),

    tfFieldName_(propsDict_.lookup("tfFieldName")),
    tf_(sm.mesh().lookupObject<volScalarField>(tfFieldName_)),

    sigmaFieldName_(propsDict_.lookup("sigmaFieldName")),
    sigma_(sm.mesh().lookupObject<volScalarField>(sigmaFieldName_)),

    UsFieldName_(propsDict_.lookup("granVelFieldName")),
    UsField_(sm.mesh().lookupObject<volVectorField> (UsFieldName_)),

    sphr_(propsDict_.lookupOrDefault<scalar>("sphr", 1.0)),
    equalDia_(propsDict_.lookupOrDefault<scalar>("equalDia", 1.0)),
    scaleDiaInput_(propsDict_.lookupOrDefault<scalar>("scaleDia", 1.0)),
    scaleDrag_(propsDict_.lookupOrDefault<scalar>("scaleDrag", 1.0)),
    RWM_(propsDict_.lookupOrDefault<scalar>("RWM", 0.0)),
    s_(propsDict_.lookupOrDefault<scalar>("s", 1.0)),
    rcut_(propsDict_.lookupOrDefault<scalar>("rcut", 0.3)),
    usek_(propsDict_.lookupOrDefault<scalar>("usek", 0.0)),
    utaum_(propsDict_.lookupOrDefault<scalar>("utaum", 0.0)),
    usex_(propsDict_.lookupOrDefault<scalar>("usex", 0.0)),
    useadv_(propsDict_.lookupOrDefault<scalar>("useadv", 0.0)),
    beta_(propsDict_.lookupOrDefault<scalar>("beta", 1.0)),
    lem_(propsDict_.lookupOrDefault<scalar>("lem", GREAT)),
    zeimcut_(propsDict_.lookupOrDefault<scalar>("zeimcut", -GREAT)),
    zcut_(propsDict_.lookupOrDefault<scalar>("zcut", 0.0)),

    AA(exp(2.3288-6.4581*sphr_+2.4486*sphr_*sphr_)),
    BB(0.0964 + 0.5565*sphr_),
    CC(exp(4.905-13.8944*sphr_+18.4222*sphr_*sphr_-10.2599*sphr_*sphr_*sphr_)),
    DD(exp(1.4681+12.2584*sphr_-20.7322*sphr_*sphr_+15.8855*sphr_*sphr_*sphr_)),

    rng_(new RNG())
{
    //Append the field names to be probed
    particleCloud_.probeM().initialize(typeName, "SamDragSlice.logDat");
    particleCloud_.probeM().vectorFields_.append("dragForce"); //first entry must the be the force
//    particleCloud_.probeM().vectorFields_.append("Urel");        //other are debug
//    particleCloud_.probeM().scalarFields_.append("Rep");          //other are debug
//    particleCloud_.probeM().scalarFields_.append("Cd");                 //other are debug
//    particleCloud_.probeM().scalarFields_.append("voidfraction");       //other are debug
    particleCloud_.probeM().writeHeader();

    particleCloud_.checkCG(true);

    // init force sub model
    setForceSubModels(propsDict_);

    // define switches which can be read from dict
//    forceSubM(0).setSwitchesList(0,true); // activate treatExplicit switch
//    forceSubM(0).setSwitchesList(2,true); // activate implDEM switch
    forceSubM(0).setSwitchesList(3,true); // activate search for verbose switch
    forceSubM(0).setSwitchesList(4,true); // activate search for interpolate switch
    forceSubM(0).setSwitchesList(8,true); // activate scalarViscosity switch

    // read those switches defined above, if provided in dict
    forceSubM(0).readSwitches();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

SamDragSlice::~SamDragSlice()
{
}

// * * * * * * * * * * * * * * * public Member Functions  * * * * * * * * * * * * * //

void SamDragSlice::setForce() const
{
    if (sphr_ < 1) {
        Info << "SamDragSlice using spherity = " << sphr_ << endl;
    }

    scalar scaleDia_ = scaleDiaInput_;
    if (scaleDia_ > 1) {
        Info << "SamDragSlice using scale = " << scaleDia_ << endl;
        Info << "equivalent diameter = " << equalDia_ << endl;
    }
    else if (particleCloud_.cg() > 1) {
        scaleDia_=particleCloud_.cg();
        Info << "SamDragSlice using scale from liggghts cg = " << scaleDia_ << endl;
    }


    voidfractionInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("voidfractionInterpolationType",word("cellPoint")),voidfraction_).ptr());
    kInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("kInterpolationType",word("cellPoint")),kit_).ptr());
    tfInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("tfInterpolationType",word("cellPoint")),tf_).ptr());
    sigmaInterpolator_.reset(interpolation<scalar>::New(propsDict_.lookupOrDefault("sigmaInterpolationType",word("cellPoint")),sigma_).ptr());
    UInterpolator_.reset(interpolation<vector>::New(propsDict_.lookupOrDefault("UInterpolationType",word("cellPointFace")),U_).ptr());

    #include "setupProbeModel.H"


    // Compute drag for all particles.

    for(int index = 0; index < particleCloud_.numberOfParticles(); ++index) {

        syncRandomWalk(index);

        const DragResult result = computeParticleDrag(index);

        if (result.cell_index < 0) continue;

        forceSubM(0).partToArray(
            index,
            result.drag,
            vector::zero,       // dragExplicit
            vector::zero,       // Ufluid
            0.0                 // dragCoefficient
        );

        if (probeIt_) {
            #include "setupProbeModelfields.H"
            vValues.append(result.drag);
            particleCloud_.probeM().writeProbe(index, sValues, vValues);
        }

        updateRandomWalk(index, result.te);
    }
}


SamDragSlice::DragResult
SamDragSlice::computeParticleDrag(int index) const
{
    const vector position = particleCloud_.position(index);

    const scalar etaa = -log(max(1.0 - rng_->random_uniform(), 1e-5));

    const label cell_index = particleCloud_.mesh().findCell(position, polyMesh::CELL_TETS);

    if (forceSubM(0).interpolation()) {

        // No sphere slicing, just interpolate values in a single cell.
        // Only a single processor needs to do this.

        if (cell_index < 0) return DragResult();

        const scalar voidfraction = voidfractionInterpolator_().interpolate(position, cell_index);
        const scalar kit = kInterpolator_().interpolate(position, cell_index);
        const scalar tf = tfInterpolator_().interpolate(position, cell_index);
        const scalar sigma = sigmaInterpolator_().interpolate(position, cell_index);
        const vector Ufluid = UInterpolator_().interpolate(position, cell_index);

        const DragResult result = computeDrag(
            index,
            cell_index,
            voidfraction,
            kit,
            tf,
            sigma,
            Ufluid,
            forceSubM(0).nuField()[cell_index],
            forceSubM(0).rhoField()[cell_index],
            etaa
        );

        return result;
    }
    else {

        // Sphere slicing, accumulate values from multiple cells.

        vector drag_total = vector::zero;
        scalar vol_frac_total = 0.0;
        scalar te_min = std::numeric_limits<scalar>::max();

        const int num_slices = particleCloud_.cellsPerParticle()[index][0];

        for(int subcell = 0; subcell < num_slices; ++subcell) {

            const label subcell_index = particleCloud_.cellIDs()[index][subcell];
            if (subcell_index < 0) continue;

            const DragResult result_slice = computeDrag(
                index,
                cell_index,
                voidfraction_[subcell_index],
                kit_[subcell_index],
                tf_[subcell_index],
                sigma_[subcell_index],
                U_[subcell_index],
                forceSubM(0).nuField()[subcell_index],
                forceSubM(0).rhoField()[subcell_index],
                etaa
            );

            const scalar slice_vol_frac = particleCloud_.particleWeights()[index][subcell];

            drag_total += result_slice.drag * slice_vol_frac;
            vol_frac_total += slice_vol_frac;

            te_min = min(te_min, result_slice.te);
        }

        reduce(drag_total, sumOp<vector>());
        reduce(vol_frac_total, sumOp<scalar>());
        reduce(te_min, minOp<scalar>());

        if (vol_frac_total > 0.0) {
            drag_total /= vol_frac_total;
        }

        return DragResult(drag_total, te_min, cell_index);
    }
}


SamDragSlice::DragResult
SamDragSlice::computeDrag(
    int index,
    int cell_index,
    scalar voidfraction,
    scalar kit,
    scalar tf,
    scalar sigma,
    vector Ufluid,
    scalar nuf,
    scalar rho,
    scalar etaa
) const
{
    vector Us = particleCloud_.velocity(index);
    vector Ur = Ufluid - Us;
    scalar magUr = mag(Ur);
    if (magUr <= 0.0) return DragResult();

    scalar scaleDia_ = scaleDiaInput_;
    if (scaleDia_ <= 1 && particleCloud_.cg() > 1) {
        scaleDia_ = particleCloud_.cg();
    }

    const vector position = particleCloud_.position(index);
    const scalar ds = 2.0 * particleCloud_.radius(index);

    const scalar twoOverThree = 2.0/3;
    const scalar sqrttwoOverThree = sqrt(twoOverThree);

    if(voidfraction>1.00) voidfraction = 1.0;
    if(voidfraction<0.3) voidfraction = 0.3;

    // fluctuation velocity scale
    scalar up, vp, wp;
    if (usek_==0)
    {
        wp=min(sqrt(mag(sigma)),utaum_);
        up=wp;
        vp=sqrt(max(2.0*kit-up*up-wp*wp,0.0));
    }
    else if(usek_==0.5)
    {
        up=sqrt((kit/1.3 + sqrt( max(sqr(kit)/1.69-2.0*sqr(sigma),0.0) ))/2.0);
        wp=mag(sigma)/max(up,1e-10);
        vp=sqrt(max(2.0*kit-up*up-wp*wp,0.0));
    }
    else
    {
        up=usek_*sqrttwoOverThree*sqrt(kit);
        vp=usek_*sqrttwoOverThree*sqrt(kit);
        wp=usek_*sqrttwoOverThree*sqrt(kit);
    }

    tf = beta_*etaa*tf;
    scalar le = sqrttwoOverThree*sqrt(kit)*tf;

    // we should limit the eddy size, and its characteristic eddy time
    // this is especially important for oscillatory flow, as the eddy turn over time
    // outside the wave boundary layer is extremely large
    le = min(le,lem_);
    tf = min(tf,lem_/utaum_);

    if(position[2]>zeimcut_+lem_)
    {
        up = 0.0;
        vp = 0.0;
        wp = 0.0;
    }

    // calc particle Re Nr
    scalar Rep = (
        ((scaleDia_ != 1) ? equalDia_ : ds)
      * voidfraction*magUr/nuf
    );

    // calc fluid drag Coeff (A. Haider and O. Lenvenspiel, 1989, Powder technology)
    scalar Xi = 3.7 - 0.65 * exp(-sqr(1.5-log10(Rep))/2.0);
    scalar Cd = (
        ((24.0/Rep)*(1.0+AA*pow(Rep,BB)) + CC/(1.0+DD/Rep))
      * pow(voidfraction,(2.0-Xi))
    );
    scalar tp = (
        ((scaleDia_ != 1) ? equalDia_ : ds)
      * 2.0*twoOverThree*s_/(magUr*Cd)
    );

    // calculate the crossing time
    scalar tc = tf;
    if(le<(tp*magUr))
    {
        tc = -tp*log(1.0 - le/(tp*magUr) );
    }
    scalar te = min(tc,tf); 

    // limit too small te will not be able to stir the deposited particles)
    te = max(te,0.41*(11.6*nuf/utaum_)/utaum_);

    if(RWM_!=0.0 && voidfraction>(1.0-rcut_))
    {
        const scalar glambda1 = ufr()[index][0];
        const scalar glambda2 = ufr()[index][1];
        const scalar glambda3 = ufr()[index][2];

        // now we update the velocity fluctuation
        scalar ux, uy, uz;
        if(usek_!=0){
            uz = wp*glambda3;
            if(position[2]<(zcut_+ds) && position[2]>=zcut_)
            {
                uz = wp*mag(glambda3);
            }
            if(position[2]>(particleCloud_.zhi_-ds))
            {
                uz = -wp*mag(glambda3);
            }
            if(usex_!=0.0)
            {
                ux = up*glambda1;
            }
            else ux = 0.0;
            uy = vp*glambda2; 
        }
        else {
            uz = wp*glambda3;
            if(position[2]<(zcut_+ds) && position[2]>=zcut_)
            {
                uz = wp*mag(glambda3);
            }
            if(position[2]>(particleCloud_.zhi_-ds))
            {
                uz = -wp*mag(glambda3);
            }
            if(usex_!=0.0)
            {
                ux = -sign(sigma)*uz+up*glambda1;
            }
            else ux = 0.0;
            uy = vp*glambda2;
        }

        Ufluid = Ufluid + RWM_ * vector(ux, uy, uz);
        Ur = Ufluid - Us;
        magUr = mag(Ur);

        // important to update the drag coefficient, as this is related to the nonlinear behavior of drag
        // calc fluid drag Coeff (A. Haider and O. Lenvenspiel, 1989, Powder technology)
        Rep = (
            ((scaleDia_ != 1) ? equalDia_ : ds)
          * voidfraction*magUr/nuf
        );
        Xi = 3.7 - 0.65 * exp(-sqr(1.5-log10(Rep))/2.0);
        Cd = (
            ((24.0/Rep)*(1.0+AA*pow(Rep,BB)) + CC/(1.0+DD/Rep))
          * pow(voidfraction,(2.0-Xi))
        );
    }

    scalar dragCoefficient = 0.125 * Cd * rho * M_PI * magUr;
    if (scaleDia_ != 1) {
        dragCoefficient *= (
            (equalDia_*equalDia_)
          / (scaleDia_*scaleDia_)
          * scaleDrag_
        );
    }
    else {
        dragCoefficient *= ds*ds;
    }

    if (modelType_ == "B")
        dragCoefficient /= voidfraction;

    vector drag = dragCoefficient * Ur;

    return DragResult(drag, te, cell_index);
}


void SamDragSlice::syncRandomWalk(int index) const
{
    // Make sure all processors have the same random walk values.

    const vector position = particleCloud_.position(index);

    if (RWM_ > 0.0 && position[2] > zeimcut_) {

        RandomWalkSyncComm tempin;
        tempin.tmark = tmark()[index][0];
        tempin.rank = Pstream::myProcNo();

        RandomWalkSyncComm tempout;
        MPI_Allreduce(&tempin, &tempout, 1, MPI_DOUBLE_INT, MPI_MAXLOC, MPI_COMM_WORLD);

        scalar gtmark = 0.0;
        scalar gti = 0.0;
        scalar glambda1 = 0.0;
        scalar glambda2 = 0.0;
        scalar glambda3 = 0.0;

        if (Pstream::myProcNo() == tempout.rank) {
            gtmark = tmark()[index][0];
            gti = ti()[index][0];
            glambda1 = ufr()[index][0];
            glambda2 = ufr()[index][1];
            glambda3 = ufr()[index][2];
        }

        reduce(gtmark, sumOp<scalar>());
        reduce(gti, sumOp<scalar>());
        reduce(glambda1, sumOp<scalar>());
        reduce(glambda2, sumOp<scalar>());
        reduce(glambda3, sumOp<scalar>());

        tmark()[index][0] = gtmark;
        ti()[index][0] = gti;
        ufr()[index][0] = glambda1;
        ufr()[index][1] = glambda2;
        ufr()[index][2] = glambda3;
    }
}


void SamDragSlice::updateRandomWalk(int index, scalar te) const
{
    // Update random walk fluctuations.
    // This takes effect on the next timestep.

    double told = particleCloud_.mesh().time().value() - particleCloud_.mesh().time().deltaTValue();
    if (RWM_ != 0.0 && (told - tmark()[index][0]) >= ti()[index][0]) {
        ufr()[index][0] = rng_->random_normal();
        ufr()[index][1] = rng_->random_normal();
        ufr()[index][2] = rng_->random_normal();
        tmark()[index][0] = particleCloud_.mesh().time().value();
        ti()[index][0] = te;
    }
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
