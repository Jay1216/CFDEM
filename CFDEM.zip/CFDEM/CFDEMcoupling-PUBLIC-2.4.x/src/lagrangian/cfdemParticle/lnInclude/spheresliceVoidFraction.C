/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright 2009-2012 JKU Linz
                                Copyright 2012-     DCS Computing GmbH, Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    This code is designed to realize coupled CFD-DEM simulations using LIGGGHTS
    and OpenFOAM(R). Note: this code is not part of OpenFOAM(R) (see DISCLAIMER).
\*---------------------------------------------------------------------------*/

#include "error.H"

#include "spheresliceVoidFraction.H"
#include "addToRunTimeSelectionTable.H"

#include <algorithm>
#include <cmath>
#include <limits>
#include <sphereslice/slice3d.h>

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(spheresliceVoidFraction, 0);

addToRunTimeSelectionTable
(
    voidFractionModel,
    spheresliceVoidFraction,
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

spheresliceVoidFraction::spheresliceVoidFraction
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    voidFractionModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),
    verbose_(false),
    alphaMin_(readScalar(propsDict_.lookup("alphaMin"))),
    periodic_x(false),
    periodic_y(false),
    periodic_z(false)
{
    maxCellsPerParticle_ = readLabel(propsDict_.lookup("maxCellsPerParticle"));

    if(alphaMin_ > 1 || alphaMin_ < 0.01) {
        FatalError << "alphaMin should be < 1 and > 0.01 !!!" << abort(FatalError);
    }

    if (propsDict_.found("verbose")) verbose_ = true;

    if (propsDict_.found("periodic")) {
        List<word> dirs(propsDict_.lookup("periodic"));
        int i;
        forAll(dirs, i) {
            if      (dirs[i] == "x") periodic_x = true;
            else if (dirs[i] == "y") periodic_y = true;
            else if (dirs[i] == "z") periodic_z = true;
            else {
                FatalError << "Unknown periodic direction " << dirs[i] << abort(FatalError);
            }
        }
    }

    if (verbose_) {
        Info
            << "In spheresliceVoidFraction constructor:" << endl
            << "  periodic_x = " << periodic_x << endl
            << "  periodic_y = " << periodic_y << endl
            << "  periodic_z = " << periodic_z << endl;
    }

    mapGridToCells();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

spheresliceVoidFraction::~spheresliceVoidFraction()
{}


// * * * * * * * * * * * * * * * Utility Functions  * * * * * * * * * * * * * //

scalar minInCell(const fvMesh& mesh, label cell_index, vector::components dir)
{
    scalar min_so_far = std::numeric_limits<scalar>::max();
    label point_index;
    forAll(mesh.cellPoints()[cell_index], point_index) {
        const vector& point = mesh.points()[
            mesh.cellPoints()[cell_index][point_index]
        ];
        min_so_far = std::min(min_so_far, point[dir]);
    }
    return min_so_far;
};

scalar maxInCell(const fvMesh& mesh, label cell_index, vector::components dir)
{
    scalar max_so_far = -std::numeric_limits<scalar>::max();
    label point_index;
    forAll(mesh.cellPoints()[cell_index], point_index) {
        const vector& point = mesh.points()[
            mesh.cellPoints()[cell_index][point_index]
        ];
        max_so_far = std::max(max_so_far, point[dir]);
    }
    return max_so_far;
};

bool isClose(scalar a, scalar b)
{
    return (std::fabs(a - b) < 1e-8 * std::max(std::fabs(a), std::fabs(b)));
};

int roundToInt(scalar x)
{
    return (int)std::floor(x + 0.5);
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void spheresliceVoidFraction::mapGridToCells()
{
    // Compute the grid lo and hi bounds, grid spacing, and the number of cells
    // in each dimension.

    grid_xlo = grid_ylo = grid_zlo =  std::numeric_limits<scalar>::max();
    grid_xhi = grid_yhi = grid_zhi = -std::numeric_limits<scalar>::max();

    bool has_local_compare = false;
    scalar grid_cell_volume = 0.0;

    const fvMesh& mesh = particleCloud_.mesh();

    label cell_index;
    forAll(mesh.cells(), cell_index) {

        const scalar cell_xlo = minInCell(mesh, cell_index, vector::X);
        const scalar cell_ylo = minInCell(mesh, cell_index, vector::Y);
        const scalar cell_zlo = minInCell(mesh, cell_index, vector::Z);
        const scalar cell_xhi = maxInCell(mesh, cell_index, vector::X);
        const scalar cell_yhi = maxInCell(mesh, cell_index, vector::Y);
        const scalar cell_zhi = maxInCell(mesh, cell_index, vector::Z);

        const scalar cell_dx = cell_xhi - cell_xlo;
        const scalar cell_dy = cell_yhi - cell_ylo;
        const scalar cell_dz = cell_zhi - cell_zlo;

        const scalar cell_volume = mesh.cellVolumes()[cell_index];

        if (has_local_compare) {
            if (
                !isClose(cell_dx, grid_dx)
             || !isClose(cell_dy, grid_dy)
             || !isClose(cell_dz, grid_dz)
             || !isClose(cell_volume, grid_cell_volume)
            ) {
                FatalError
                    << "Cells must be regular rectangular hex shape, cell " << cell_index << " has "
                    << "dx = " << cell_dx << " (prev = " << grid_dx << ", isClose " << isClose(cell_dx, grid_dx) << "), "
                    << "dy = " << cell_dy << " (prev = " << grid_dy << ", isClose " << isClose(cell_dy, grid_dy) << "), "
                    << "dz = " << cell_dz << " (prev = " << grid_dz << ", isClose " << isClose(cell_dz, grid_dz) << "), "
                    << "volume = " << cell_volume << " (prev = " << grid_cell_volume << ", isClose " << isClose(cell_volume, grid_cell_volume) << ")"
                    << abort(FatalError);
            }
        }
        else {
            has_local_compare = true;
            grid_dx = cell_dx;
            grid_dy = cell_dy;
            grid_dz = cell_dz;
            grid_cell_volume = cell_volume;
        }

        grid_xlo = std::min(grid_xlo, cell_xlo);
        grid_ylo = std::min(grid_ylo, cell_ylo);
        grid_zlo = std::min(grid_zlo, cell_zlo);
        grid_xhi = std::max(grid_xhi, cell_xhi);
        grid_yhi = std::max(grid_yhi, cell_yhi);
        grid_zhi = std::max(grid_zhi, cell_zhi);
    }

    reduce(grid_xlo, minOp<scalar>());
    reduce(grid_ylo, minOp<scalar>());
    reduce(grid_zlo, minOp<scalar>());
    reduce(grid_xhi, maxOp<scalar>());
    reduce(grid_yhi, maxOp<scalar>());
    reduce(grid_zhi, maxOp<scalar>());

    grid_nx = roundToInt((grid_xhi - grid_xlo) / grid_dx);
    grid_ny = roundToInt((grid_yhi - grid_ylo) / grid_dy);
    grid_nz = roundToInt((grid_zhi - grid_zlo) / grid_dz);

    if (verbose_) {
        Info
            << "In spheresliceVoidFraction::mapGridToCells():" << endl
            << "  grid_xlo = " << grid_xlo << endl
            << "  grid_ylo = " << grid_ylo << endl
            << "  grid_zlo = " << grid_zlo << endl
            << "  grid_xhi = " << grid_xhi << endl
            << "  grid_yhi = " << grid_yhi << endl
            << "  grid_zhi = " << grid_zhi << endl
            << "  grid_dx = " << grid_dx << endl
            << "  grid_dy = " << grid_dy << endl
            << "  grid_dz = " << grid_dz << endl
            << "  grid_nx = " << grid_nx << endl
            << "  grid_ny = " << grid_ny << endl
            << "  grid_nz = " << grid_nz << endl;
    }

    // Create a mapping from the grid used for sphere slicing, to the
    // corresponding local cell indexes in the OpenFOAM mesh.

    grid_to_cell_list.resize(grid_nx * grid_ny * grid_nz, -1);

    forAll(mesh.cells(), cell_index) {
        const vector& center_point = mesh.cellCentres()[cell_index];
        const int ix = static_cast<int>((center_point.x() - grid_xlo) / grid_dx);
        const int iy = static_cast<int>((center_point.y() - grid_ylo) / grid_dy);
        const int iz = static_cast<int>((center_point.z() - grid_zlo) / grid_dz);
        grid_to_cell(ix, iy, iz) = cell_index;
    }

    if (debug) {
        Info << "  On root proc:" << endl;
        for (int ix = 0; ix < grid_nx; ++ix) {
            for (int iy = 0; iy < grid_ny; ++iy) {
                for (int iz = 0; iz < grid_nz; ++iz) {
                    Info
                        << "    grid_to_cell(" << ix << ", " << iy << ", " << iz
                        << ") = " << grid_to_cell(ix, iy, iz) << endl;
                }
            }
        }
    }
}


void spheresliceVoidFraction::setvoidFraction(
    double** const& mask,
    double**& voidfractions,
    double**& particleWeights,
    double**& particleVolumes,
    double**& particleV
) const
{
    // Calculate void fraction contributions from all necessary particles.

    reAllocArrays();

    for(int index = 0; index < particleCloud_.numberOfParticles(); ++index) {
        if(!checkParticleType(index)) continue;

        // Initialize particle concentrations to 0.

        for(int subcell = 0; subcell < cellsPerParticle_[index][0]; ++subcell) {
            particleWeights[index][subcell] = 0.0;
            particleVolumes[index][subcell] = 0.0;
            voidfractions[index][subcell] = 1.0;
        }
        particleV[index][0] = 0.0;

        cellsPerParticle_[index][0] = 0;

        // Do 3D sphere slicing.

        const vector center = particleCloud_.position(index);
        const scalar radius = particleCloud_.radius(index);
        const scalar volume = 4.0/3 * M_PI * radius*radius*radius;

        const Slices3D slices(
            center.x(), center.y(), center.z(),
            radius,
            grid_xlo, grid_dx,
            grid_ylo, grid_dy,
            grid_zlo, grid_dz
        );

        // For each slice, update that cell's void fraction if it is inside our
        // processor's domain.

        for (int sx = 0; sx < slices.getNumSlicesX(); ++sx) {
            int ix = sx + slices.getFirstSliceX();
            if (ix < 0) {
                if (!periodic_x) continue;
                ix += grid_nx;
            }
            if (ix >= grid_nx) {
                if (!periodic_x) continue;
                ix -= grid_nx;
            }

            for (int sy = 0; sy < slices.getNumSlicesY(); ++sy) {
                int iy = sy + slices.getFirstSliceY();
                if (iy < 0) {
                    if (!periodic_y) continue;
                    iy += grid_ny;
                }
                if (iy >= grid_ny) {
                    if (!periodic_y) continue;
                    iy -= grid_ny;
                }

                for (int sz = 0; sz < slices.getNumSlicesZ(); ++sz) {
                    int iz = sz + slices.getFirstSliceZ();
                    if (iz < 0) {
                        if (!periodic_z) continue;
                        iz += grid_nz;
                    }
                    if (iz >= grid_nz) {
                        if (!periodic_z) continue;
                        iz -= grid_nz;
                    }

                    const label cell_index = grid_to_cell(ix, iy, iz);
                    if (cell_index < 0) continue;

                    const scalar cell_volume = particleCloud_.mesh().cellVolumes()[cell_index];
                    const scalar slice_vol_frac = slices.get(sx, sy, sz);
                    const scalar slice_volume = volume * slice_vol_frac;
                    const scalar slice_voidfraction = slice_volume / cell_volume;

                    const int subcell = cellsPerParticle_[index][0];
                    ++cellsPerParticle_[index][0];

                    particleWeights[index][subcell] += slice_vol_frac;
                    particleVolumes[index][subcell] += slice_volume;
                    particleV[index][0] += slice_volume;
                    particleCloud_.cellIDs()[index][subcell] = cell_index;

                    voidfractions[index][subcell] = std::max(
                        voidfractions[index][subcell] - slice_voidfraction,
                        alphaMin_
                    );
                    voidfractionNext_[cell_index] = std::max(
                        voidfractionNext_[cell_index] - slice_voidfraction,
                        alphaMin_
                    );
                }
            }
        }
    }

    voidfractionNext_.correctBoundaryConditions();
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
