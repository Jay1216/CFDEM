/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright 2009-2012 JKU Linz
                                Copyright 2012-     DCS Computing GmbH, Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    This code is designed to realize coupled CFD-DEM simulations using LIGGGHTS
    and OpenFOAM(R). Note: this code is not part of OpenFOAM(R) (see DISCLAIMER).
\*---------------------------------------------------------------------------*/

#include "error.H"

#include "gradPForce.H"
#include "addToRunTimeSelectionTable.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(gradPForce, 0);

addToRunTimeSelectionTable
(
    forceModel,
    gradPForce,
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
gradPForce::gradPForce
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    forceModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),
    pFieldName_(propsDict_.lookup("pFieldName")),
    p_(sm.mesh().lookupObject<volScalarField> (pFieldName_)),
    gradpFieldName_(propsDict_.lookup("gradpFieldName")),
    gradp_(sm.mesh().lookupObject<volVectorField> (gradpFieldName_)),
    voidfractionFieldName_(propsDict_.lookup("voidfractionFieldName")),
    voidfraction_(sm.mesh().lookupObject<volScalarField> (voidfractionFieldName_)),
    velocityFieldName_(propsDict_.lookup("velocityFieldName")),
    U_(sm.mesh().lookupObject<volVectorField> (velocityFieldName_)),
    useRho_(false),
    useU_(false),
    addedMassCoeff_(0.0),
    dpm_(0.0),
    dp1_(0.0),
    dp2_(0.0),
    dp3_(0.0),
    dp4_(0.0),
    dp5_(0.0),
    dp6_(0.0),
    waveShape_(1.0),
    period_(1.0),
    theta_(0.0),
    thetaShape_(-90.0),
    assy_ (0.0),
    rcut_(0.6)
{
    // init force sub model
    setForceSubModels(propsDict_);

    // define switches which can be read from dict
    forceSubM(0).setSwitchesList(0,true); // activate treatExplicit switch
    forceSubM(0).setSwitchesList(1,true); // activate treatForceDEM switch
    forceSubM(0).setSwitchesList(4,true); // activate search for interpolate switch

    //set default switches (hard-coded default = false)
    forceSubM(0).setSwitches(0,true);  // enable treatExplicit, otherwise this force would be implicit in slip vel! - IMPORTANT!

    for (int iFSub=0;iFSub<nrForceSubModels();iFSub++)
        forceSubM(iFSub).readSwitches();

    if (modelType_ == "B")
    {
        FatalError <<"using  model gradPForce with model type B is not valid\n" << abort(FatalError);
    }else if (modelType_ == "Bfull")
    {
        if(forceSubM(0).switches()[1])
        {
            Info << "Using treatForceDEM false!" << endl;
            forceSubM(0).setSwitches(1,false); // treatForceDEM = false
        }
    }else // modelType_=="A"
    {
        if(!forceSubM(0).switches()[1])
        {
            Info << "Using treatForceDEM true!" << endl;
            forceSubM(0).setSwitches(1,true); // treatForceDEM = true
        }
    }

    if (propsDict_.found("useU")) useU_=true;
    if (propsDict_.found("useAddedMass")) 
    {
        addedMassCoeff_ =  readScalar(propsDict_.lookup("useAddedMass"));
        Info << "gradP will also include added mass with coefficient: " << addedMassCoeff_ << endl;
        Info << "WARNING: use fix nve/sphere/addedMass in LIGGGHTS input script to correctly account for added mass effects!" << endl;
    }

    if (propsDict_.found("dpm"))
        dpm_=scalar(readScalar(propsDict_.lookup("dpm")));
    if (propsDict_.found("dp1"))
        dp1_=scalar(readScalar(propsDict_.lookup("dp1")));
    if (propsDict_.found("dp2"))
        dp2_=scalar(readScalar(propsDict_.lookup("dp2")));
    if (propsDict_.found("dp3"))
        dp3_=scalar(readScalar(propsDict_.lookup("dp3")));
    if (propsDict_.found("dp4"))
        dp4_=scalar(readScalar(propsDict_.lookup("dp4")));
    if (propsDict_.found("dp5"))
        dp5_=scalar(readScalar(propsDict_.lookup("dp5")));
    if (propsDict_.found("dp6"))
        dp6_=scalar(readScalar(propsDict_.lookup("dp6")));
    if (propsDict_.found("period"))
        period_=scalar(readScalar(propsDict_.lookup("period")));
    if (propsDict_.found("theta"))
        theta_=scalar(readScalar(propsDict_.lookup("theta")));
    if (propsDict_.found("thetaShape"))
        thetaShape_=scalar(readScalar(propsDict_.lookup("thetaShape")));
    if (propsDict_.found("assy"))
        assy_=scalar(readScalar(propsDict_.lookup("assy")));
    if (propsDict_.found("waveShape"))
        waveShape_=scalar(readScalar(propsDict_.lookup("waveShape")));
    if (propsDict_.found("rcut"))
        rcut_=scalar(readScalar(propsDict_.lookup("rcut")));

    if(p_.dimensions()==dimensionSet(0,2,-2,0,0))
        useRho_ = true;

    particleCloud_.checkCG(true);

    // suppress particle probe
    if (probeIt_ && propsDict_.found("suppressProbe"))
        probeIt_=!Switch(propsDict_.lookup("suppressProbe"));
    if(probeIt_)
    {
        particleCloud_.probeM().initialize(typeName, typeName+".logDat");
        particleCloud_.probeM().vectorFields_.append("gradPForce"); //first entry must the be the force
        particleCloud_.probeM().scalarFields_.append("Vs");
        particleCloud_.probeM().scalarFields_.append("rho");
        particleCloud_.probeM().writeHeader();
    }
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

gradPForce::~gradPForce()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void gradPForce::setForce() const
{
    volVectorField gradP_ = gradp_;//fvc::grad(p_);
    /*if (useU_)
    {
        // const volScalarField& voidfraction_ = particleCloud_.mesh().lookupObject<volScalarField> ("voidfraction");
        volScalarField U2 = U_&U_;// *voidfraction_*voidfraction_;
        if (useRho_)
            gradP_ = fvc::grad(0.5*U2);
        else
            gradP_ = fvc::grad(0.5*forceSubM(0).rhoField()*U2);
    }*/

    // added to add mean pressure forcing
    scalar tre = particleCloud_.mesh().time().value();

    vector gradpre (0.0,0.0,0.0);

    if (waveShape_ == 1.0)  //stokes
    {
        gradpre = (dpm_+dp1_*cos(2.0*M_PI*tre/period_+theta_*(M_PI)/180.0)+dp2_*sin(4.0*M_PI*tre/period_+2.0*theta_*(M_PI)/180.0))*vector(1.0,0.0,0.0);
    }
  
    if (waveShape_ == 2.0)   //sawtooth
    {
       gradpre = (dpm_+dp1_*cos(2.0*M_PI*tre/period_)+dp2_*cos(2.0*2.0*M_PI*tre/period_)+dp3_*cos(3.0*2*M_PI*tre/period_)+dp4_*cos(4*2.0*M_PI*tre/period_)+dp5_*cos(5*2.0*M_PI*tre/period_)+dp6_*cos(6*2.0*M_PI*tre/period_))*vector(1.0,0.0,0.0);
    }

    if (waveShape_ == 3.0)   //sawtooth
    {
       gradpre = (dpm_+dp1_/pow (1 - assy_ * cos(2*M_PI/period_*tre+thetaShape_*M_PI/180+theta_*M_PI/180) , 2 )*cos(2*M_PI/period_*tre+theta_*M_PI/180)+dp2_/pow (1 - assy_ * cos(2*M_PI/period_*tre+thetaShape_*M_PI/180+theta_*M_PI/180) , 2 )*cos(2*M_PI/period_*tre+2*thetaShape_*M_PI/180+theta_*M_PI/180)+dp3_/pow (1 - assy_ * cos(2*M_PI/period_*tre+thetaShape_*M_PI/180+theta_*M_PI/180) , 2 )*cos(thetaShape_*M_PI/180))*vector(1.0,0.0,0.0);
    }

    // end of add
    vector gradP;
    scalar voidfraction(1.0);
    scalar Vs;
    scalar rho;
    vector position;
    vector force;
    label cellI;

    #include "resetGradPInterpolator.H"
    #include "resetVoidfractionInterpolator.H"
    #include "setupProbeModel.H"

    for(int index = 0;index <  particleCloud_.numberOfParticles(); index++)
    {
        //if(mask[index][0])
        //{
            force=vector(0,0,0);
            cellI = particleCloud_.cellIDs()[index][0];

            if (cellI > -1) // particle Found
            {
                position = particleCloud_.position(index);

                if(forceSubM(0).interpolation()) // use intepolated values for alpha (normally off!!!)
                {
                    gradP = gradPInterpolator_().interpolate(position,cellI);
                    voidfraction = voidfractionInterpolator_().interpolate(position,cellI);
                }else
                {
                    gradP = gradP_[cellI];
                    voidfraction = voidfraction_[cellI];
                }

//                if(voidfraction<(1.0-rcut_))
//                {
//                 gradP = - gradpre;
//                }
//                else
//                {
//                 gradP = gradP - gradpre;
//                }
                if(voidfraction > (1.0-rcut_))
                {
                    gradP = gradP  - gradpre;
                }                
                if(index==100)
                {
                Pout<<"force=-gradP= "<<-gradP<<endl;
                Pout<<"gradpre = "<<gradpre<<endl;
                }

                Vs = particleCloud_.particleVolume(index);
                rho = forceSubM(0).rhoField()[cellI];

                // calc particle's pressure gradient force
                if (useRho_)
                    force = -Vs*gradP*rho*(1.0+addedMassCoeff_);
                else
                    force = -Vs*gradP*(1.0+addedMassCoeff_);

                if(forceSubM(0).verbose() && index >=0 && index <2)
                {
                    Info << "index = " << index << endl;
                    Info << "gradP = " << gradP << endl;
                    Info << "force = " << force << endl;
                }

                //Set value fields and write the probe
                if(probeIt_)
                {
                    #include "setupProbeModelfields.H"
                    // Note: for other than ext one could use vValues.append(x)
                    // instead of setSize
                    vValues.setSize(vValues.size()+1, force);           //first entry must the be the force
                    sValues.setSize(sValues.size()+1, Vs);
                    sValues.setSize(sValues.size()+1, rho);
                    particleCloud_.probeM().writeProbe(index, sValues, vValues);
                }
            }

            // write particle based data to global array
            forceSubM(0).partToArray(index,force,vector::zero);

        //}
    }
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
