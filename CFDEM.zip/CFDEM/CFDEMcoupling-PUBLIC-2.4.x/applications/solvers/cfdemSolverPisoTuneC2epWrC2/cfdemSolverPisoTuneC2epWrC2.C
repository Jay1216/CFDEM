/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright (C) 1991-2009 OpenCFD Ltd.
                                Copyright (C) 2009-2012 JKU, Linz
                                Copyright (C) 2012-     DCS Computing GmbH,Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling.  If not, see <http://www.gnu.org/licenses/>.

Application
    cfdemSolverPiso

Description
    Transient solver for incompressible flow.
    Turbulence modelling is generic, i.e. laminar, RAS or LES may be selected.
    The code is an evolution of the solver pisoFoam in OpenFOAM(R) 1.6,
    where additional functionality for CFD-DEM coupling is added.
\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "wallDist.H"
#include "nearWallDist.H"
#include "wallFvPatch.H"
#include "Switch.H"
#include "IFstream.H"
#include "OFstream.H"
#include "symmetryFvPatchFields.H"
#include "fixedGradientFvPatchFields.H"
#include "fixedFluxPressureFvPatchScalarField.H"
#include "outletInletFvPatchFields.H"

#include "singlePhaseTransportModel.H"
#include "turbulenceModel.H"
#include "bound.H"
#include "cfdemCloud.H"
#include "implicitCouple.H"
#include "clockModel.H"
#include "smoothingModel.H"
#include "forceModel.H"
// Added for KEpsilon model
#include "fixedValueFvsPatchFields.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    #include "createFields.H"
    #include "createGradP.H"
    #include "initContinuityErrs.H"

    // create cfdemCloud
    #include "readGravitationalAcceleration.H"
    cfdemCloud particleCloud(mesh);
    #include "checkModelType.H"

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    while (runTime.loop())
    {
        Info<< "\nStarting time loop\n" << endl;
            particleCloud.clockM().start(1,"Global");

        Info<< "Time = " << runTime.timeName() << nl << endl;

        #include "readPISOControls.H"
        #include "CourantNo.H"

        particleCloud.clockM().start(2,"Coupling");
        bool hasEvolved = particleCloud.evolve(voidfraction,Us,Fluxs,U);

        if(hasEvolved)
        {
            particleCloud.smoothingM().smoothen(particleCloud.forceM(0).impParticleForces());
        }

        Info << "update Ksl.internalField()" << endl;
        Ksl = particleCloud.momCoupleM(0).impMomSource();
        Ksl.correctBoundaryConditions();

        // Force Check
        vector fTotal(0,0,0);
       vector fImpTotal = sum(mesh.V()*Ksl.internalField()*(Us.internalField()-U.internalField()));
       reduce(fImpTotal, sumOp<vector>());
       Info << "TotalForceExp: " << fTotal << endl;
       Info << "TotalForceImp: " << fImpTotal << endl;

        // Here add the pressure driven force
        scalar pi = constant::mathematical::pi;
        gradPOSC = gradPMEAN+gradPAMP1*Foam::cos(initTheta*pi/180.0+2.0*pi*runTime.value()/oscpT)+gradPAMP2*Foam::sin(initTheta*pi/90.0+4.0*pi*runTime.value()/oscpT);

        Info << "pressure gradient force: " << gradPOSC.value() << endl;

        #include "solverDebugInfo.H"
        
        particleCloud.clockM().stop("Coupling");

        particleCloud.clockM().start(26,"Flow");

        word schemeA("div(alpha,nu)");
 
        if(particleCloud.solveFlow())
        {
            // Pressure-velocity PISO corrector
            {
                //turbulence->correct();
                //#include "turbulence.H"
                if(modelType == "B") nuEff = (nut+nu)/voidfraction;
             
                //exactly like SedFOAM
                //#include "ULimit.H"
                //#include "UsLimit.H"
                volTensorField gradUbT = fvc::grad(U)().T();
                volTensorField gradUb = fvc::grad(U);
                volTensorField Rcb
                (
                   "Rcb",
                   ((2.0/3.0)*I)*(k + nuEff*tr(gradUbT)) - nuEff*gradUbT
                );

                surfaceScalarField phiRb =
                     -fvc::interpolate(nuEff)*mesh.magSf()*(fvc::snGrad(voidfraction))
                     /fvc::interpolate(voidfraction);

                surfaceScalarField phib = fvc::interpolate(U) & mesh.Sf();
                // Momentum predictor
                fvVectorMatrix UEqn
                (
                    fvm::ddt(U)
                  + fvm::div(phib,U,"div(phi,U)")
                  - fvm::Sp(fvc::div(phib), U)
// following two lines, Zhen Cheng's version 
                  - fvm::laplacian(nuEff,U,"laplacian(nuEff,U)")
                  //+ fvm::div(phiRb, U, "div(phi,U)")
                  //- fvm::Sp(fvc::div(phiRb), U)
                  + fvc::div(Rcb)
                  //+ (fvc::grad(voidfraction)/(voidfraction) & Rcb)
                  ==
                  - fvm::Sp(Ksl/(voidfraction*rho),U)
//                  + Ksl/(voidfraction*rho)*Us
                );

                if (modelType=="B")
                    UEqn == - fvc::grad(p)/voidfraction
                        + g
                        + Ksl/(voidfraction*rho)*Us
                        + gradPOSC;
                else
                    UEqn == - fvc::grad(p)
                        + g
                        + Ksl/(voidfraction*rho)*Us
                        + gradPOSC;

                UEqn.relax();

                if (momentumPredictor)
                    solve(UEqn);

                // --- PISO loop

                //for (int corr=0; corr<nCorr; corr++)
                int nCorrSoph = nCorr + 5 * pow((1-particleCloud.dataExchangeM().timeStepFraction()),1);

                Info << "n loop becomes " << nCorrSoph << endl;

                for (int corr=0; corr<nCorrSoph; corr++)
                {
                    volScalarField rUA = 1.0/UEqn.A();

                    surfaceScalarField rUAf("(1|A(U))", fvc::interpolate(rUA));

                    surfaceScalarField phiS(fvc::interpolate(Us) & mesh.Sf());

                    surfaceScalarField phiDragb
                    (
                        rUAf*(g & mesh.Sf())
                        + rUAf*(gradPOSC & mesh.Sf()) 
                        + rUAf*fvc::interpolate(Ksl/(voidfraction*rho))*phiS
                    );

                    U = rUA*UEqn.H();

                    forAll(p.boundaryField(), patchi)
                    {
                         if (isA<zeroGradientFvPatchScalarField>(p.boundaryField()[patchi]))
                         {
                            phiDragb.boundaryField()[patchi] = 0.0;
                         }
                         if (p.boundaryField().types()[patchi] == "symmetryPlane")
                         {
                            phiDragb.boundaryField()[patchi] = 0.0;
                         }
                         if (p.boundaryField().types()[patchi] == "fixedFluxPressure")
                         {
                            phiDragb.boundaryField()[patchi] = 0.0;
                         }
                    }  

                    surfaceScalarField phiU = (fvc::interpolate(U) & mesh.Sf()) + rUAf*fvc::ddtCorr(U, phib);
                    phib = phiU + phiDragb;
                    surfaceScalarField phi = fvc::interpolate(voidfraction)*(phib)+fvc::interpolate(1-voidfraction)*phiS;
                    surfaceScalarField alphaf = fvc::interpolate(1-voidfraction);
                    surfaceScalarField betaf = fvc::interpolate(voidfraction);

                    volScalarField rUAvoidfraction("(voidfraction2|A(U))",rUA);
                    if (modelType=="A")
                        rUAvoidfraction = volScalarField("(voidfraction2|A(U))",rUA*voidfraction);

                    surfaceScalarField rUAvoidfractionf(fvc::interpolate(rUAvoidfraction));

                    setSnGrad<fixedFluxPressureFvPatchScalarField>
                    (
                      p.boundaryField(),
                      (
                        phi.boundaryField()
                          - (alphaf.boundaryField()*(mesh.Sf().boundaryField() & Us.boundaryField())
                          + betaf.boundaryField()*(mesh.Sf().boundaryField() & U.boundaryField())
                            )
                      ) / (mesh.magSf().boundaryField()*rUAvoidfractionf.boundaryField())
                    );

                    // Non-orthogonal pressure corrector loop
                    for (int nonOrth=0; nonOrth<=nNonOrthCorr; nonOrth++)
                    {
                        volScalarField ddtalpha = fvc::average(fvc::ddt(voidfraction));
                        // Pressure corrector
                        fvScalarMatrix pEqn
                        (
                            fvm::laplacian(rUAvoidfractionf, p) == fvc::div(phi)
                        );
                        pEqn.setReference(pRefCell, pRefValue);

                        if
                        (
                            corr == nCorr-1
                         && nonOrth == nNonOrthCorr
                        )
                        {
                            pEqn.solve(mesh.solver("pFinal"));
                        }
                        else
                        {
                            pEqn.solve();
                        }

                        if (nonOrth == nNonOrthCorr)
                        {
                            surfaceScalarField SfGradp(pEqn.flux()/rUAvoidfractionf);
                            phib -= rUAf*SfGradp;
                            gradp = fvc::reconstruct(SfGradp);
                            #include "GradpLimit.H"
                            phi -= pEqn.flux();
                        }

                    } // end non-orthogonal corrector loop

                    #include "continuityErrorPhiPUnew.H"
                    U += rUA*fvc::reconstruct((phib-phiU)/rUAf);
                    //#include "ULimit.H"
                    U.correctBoundaryConditions();

                } // end piso loop
            }
           
             Info<< "min(U) = " <<min(U).value() << "max(U) = " <<max(U).value()  << endl;
        }// end solveFlow
        else
        {
            Info << "skipping flow solution." << endl;
        }

        #include "turbulenceCFDEM.H"

        #include "write.H" 

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;

        particleCloud.clockM().stop("Flow");
        particleCloud.clockM().stop("Global");
    }

    Info<< "End\n" << endl;
    
    return 0;
}

// ************************************************************************* //
